export const NotFoundPage = () => {
  return (
    <div className="notfound">
      <img src="https://miro.medium.com/max/1400/1*RdC2SWhfDU55fnlYnj2DOg.gif" alt="404 Error Not found" />
    </div>
  );
};

import React from 'react'

function Hello() {
  return (
    <div>
        <h2>hello, Welcome to Home Page</h2>
    </div>
  )
}

export default Hello